function eindscherm() {
    const main = document.querySelector("main");
    main.innerHTML = `
    <section class="eindscherm">
        <h2>Je hebt gewonnen!</h2>
        <button id="herstart-knop">Herstart</button>
    </section>
    `;
    document.getElementById("herstart-knop").addEventListener("click", herstartSpel);
}
