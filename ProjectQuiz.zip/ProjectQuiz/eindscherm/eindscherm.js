document.addEventListener("DOMContentLoaded", () => {
    const name = localStorage.getItem("spelernaam");
    if (name) {
        document.getElementById("spelernaam").textContent = name;
    }

    const eindscore = localStorage.getItem("eindscore");
    if (eindscore) {
        document.getElementById("eindscore").textContent = eindscore;
    }

    const maximalescore = localStorage.getItem("maximalescore");
    if (maximalescore) {
        document.getElementById("maximalescore").textContent = maximalescore;
    }
});

function opnieuwquiz() {
    localStorage.clear()
    window.location.href = "../startscherm/startscherm.html";
}
