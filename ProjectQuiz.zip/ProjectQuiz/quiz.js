function nextScreen(nr) {
    if (nr === 2) {
        const nameInput = document.querySelector('.inputname');
        if (!nameInput || nameInput.value.trim() === "") {
            alert("Please enter your name!");
            return;
        }
        localStorage.setItem('spelernaam', nameInput.value.trim());
    }

    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    const next = document.getElementById('screen' + nr);
    if (next) next.classList.add('active');

    const naam = localStorage.getItem('spelernaam');
    if (naam) document.querySelectorAll('#spelernaam').forEach(span => span.textContent = naam);

    if (nr === 3) {
        const gekozenThema = localStorage.getItem("gekozenThema");
        if (gekozenThema) {
            const themaSpan = document.getElementById("gekozenThema");
            if (themaSpan) themaSpan.textContent = gekozenThema;
            laadVragen(gekozenThema);
        }
    }

    if (nr === 4) {
        const score = localStorage.getItem("score");
        const maxScore = localStorage.getItem("maxScore");
        if (score && maxScore) {
            document.getElementById("score").textContent = score;
            document.getElementById("maxscore").textContent = maxScore;
        }
    }
}

document.addEventListener("DOMContentLoaded", () => {
    const opgeslagenNaam = localStorage.getItem("spelernaam");
    if (opgeslagenNaam) {
        const input = document.querySelector('.inputname');
        if (input) input.value = opgeslagenNaam;
        document.querySelectorAll('#spelernaam').forEach(span => span.textContent = opgeslagenNaam);
    }

    document.querySelectorAll(".thema").forEach(thema => {
        thema.addEventListener("click", () => {
            localStorage.setItem("gekozenThema", thema.textContent);
            nextScreen(3);
        });
    });
});

function shuffleArray(array) {
    const newArr = [...array];
    for (let i = newArr.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [newArr[i], newArr[j]] = [newArr[j], newArr[i]];
    }
    return newArr;
}

function laadVragen(thema) {
    let index = 0;
    let score = 0;

    fetch("vragen.json")
        .then(r => r.json())
        .then(data => {
            let vragenArray = [];
            if (thema === "Indonesisch eten") vragenArray = data.IndonesischEten;
            else if (thema === "GameCharacter") vragenArray = data.GameCharacter;
            else if (thema === "Gezondheid") vragenArray = data.Gezondheid;

            vragenArray = shuffleArray(vragenArray);

            if (!vragenArray.length) {
                alert("Geen vragen gevonden voor dit thema.");
                return;
            }

            function toonVraag(i) {
                const vraag = vragenArray[i];
                document.querySelector(".vraagtitel").textContent = vraag.vraag;
                document.querySelector(".vraagimage").src = "images/" + vraag.image;

                const knoppen = document.querySelectorAll(".antwoord");
                const antwoorden = vraag.antwoorden.map((tekst, idx) => ({
                    tekst,
                    correct: idx === 0
                }));

                const shuffled = shuffleArray(antwoorden);

                knoppen.forEach((knop, j) => {
                    knop.textContent = shuffled[j].tekst;
                    knop.onclick = () => {
                        clearInterval(countdown);
                        if (shuffled[j].correct) score++;
                        i++;
                        if (i < vragenArray.length) toonVraag(i);
                        else {
                            localStorage.setItem("score", score);
                            localStorage.setItem("maxScore", vragenArray.length);
                            nextScreen(4);
                        }
                    };
                });

                let timeLeft = 20;
                const timerDisplay = document.querySelector(".timer");
                if (timerDisplay) timerDisplay.textContent = timeLeft;

                const countdown = setInterval(() => {
                    timeLeft--;
                    if (timerDisplay) timerDisplay.textContent = timeLeft;
                    if (timeLeft <= 0) {
                        clearInterval(countdown);
                        i++;
                        if (i < vragenArray.length) toonVraag(i);
                        else {
                            localStorage.setItem("score", score);
                            localStorage.setItem("maxScore", vragenArray.length);
                            nextScreen(4);
                        }
                    }
                }, 1000);
            }

            toonVraag(index);
        });
}
