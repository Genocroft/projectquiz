// ==============================
// FUNCTIE: Scherm wisselen
// ==============================
function nextScreen(nr) {
    // Naam validatie alleen voor scherm 1
    if (nr === 2) {
        const nameInput = document.querySelector('.inputname').value;
        if (nameInput.trim() === "") {
            alert("Please enter your name!");
            return;
        }
        localStorage.setItem('spelernaam', nameInput);
    }

    // Alle schermen verbergen
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));

    // Volgend scherm tonen
    const next = document.getElementById('screen' + nr);
    if (next) next.classList.add('active');

    // Naam tonen op scherm 2 en 3
    const naam = localStorage.getItem('spelernaam');
    if (naam) {
        const spelerNaamSpan = document.getElementById('spelernaam');
        if (spelerNaamSpan) spelerNaamSpan.textContent = naam;
    }

    // Thema tonen op screen3
    if (nr === 3) {
        const gekozenThema = localStorage.getItem("gekozenThema");
        if (gekozenThema) {
            const themaSpan = document.getElementById("gekozenThema");
            if(themaSpan) themaSpan.textContent = gekozenThema;

            // Laad de vragen voor het gekozen thema
            laadVragen(gekozenThema);
        }
    }
}

// ==============================
// FUNCTIE: Thema selectie (screen2)
// ==============================
document.addEventListener("DOMContentLoaded", () => {
    // Naam automatisch invullen op scherm1 (als teruggekomen)
    const opgeslagenNaam = localStorage.getItem("spelernaam");
    if(opgeslagenNaam){
        const input = document.querySelector('.inputname');
        if(input) input.value = opgeslagenNaam;
    }

    // Klik-events voor thema's in screen2
    const themas = document.querySelectorAll(".thema");
    themas.forEach((thema) => {
        thema.addEventListener("click", () => {
            localStorage.setItem("gekozenThema", thema.textContent);
            nextScreen(3);
        });
    });
});

// ==============================
// FUNCTIE: Vragen laden voor screen3
// ==============================
function laadVragen(thema) {
    let index = 0;
    fetch("vragenscherm.json")
        .then(r => r.json())
        .then(data => {
            // Kies de juiste array afhankelijk van het thema
            let vragenArray;
            if (thema === "Indonesisch eten") vragenArray = data.IndonesischEten;
            else if (thema === "GameCharacter") vragenArray = data.GameCaracter;
            else if (thema === "Gezondheid") vragenArray = data.Gezondheid;
            else vragenArray = [];

            function toonVraag(i) {
                const vraag = vragenArray[i];
                document.querySelector(".vraagtitel").textContent = vraag.vraag;
                document.querySelector(".vraagimage").src = "images/" + vraag.image;

                const knoppen = document.querySelectorAll(".antwoord");
                knoppen.forEach((knop, j) => {
                    knop.textContent = vraag.antwoorden[j];
                    knop.onclick = () => {
                        i++;
                        if (i < vragenArray.length) {
                            toonVraag(i);
                        } else {
                            alert("Quiz klaar!"); // Hier kun je doorsturen naar eindscherm
                        }
                    };
                });
            }

            toonVraag(index);
        });
}
