document.addEventListener("DOMContentLoaded", () => {
  let index = 0;
  fetch("vragenscherm.json")
    .then(r => r.json())
    .then(data => {

    
      const IndonesischEten = data.IndonesischEten;
      const CodeTalen = data.HetVerleden;
      const Gezondheid = data.Gezondheid;

      function toonVraag(index) {
        const vraag = IndonesischEten[index];
        document.querySelector(".vraagtitel").textContent = vraag.vraag;
        document.getElementById("vraagimage").src = "vragenscherm/" + vraag.image;

        const knoppen = document.querySelectorAll(".antwoord");
        knoppen.forEach((knop, i) => {
          knop.textContent = vraag.antwoorden[i];
          knop.onclick = () => {
            index++;
            if (index < IndonesischEten.length) {
              toonVraag(index);
            }
          };
        });
      }
      toonVraag(index);
    });
});
