  function nextScreen(nr) {
    if (nr === 2) {
      const nameInput = document.querySelector('.inputname');
      if (!nameInput || nameInput.value.trim() === "") {
        alert("Please enter your name!");
        return;
      }
      localStorage.setItem('spelernaam', nameInput.value.trim());
    }

    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    const next = document.getElementById('screen' + nr);
    if (next) next.classList.add('active');

    const naam = localStorage.getItem('spelernaam');
    if (naam) document.querySelectorAll('#spelernaam').forEach(span => span.textContent = naam);

    if (nr === 3) {
      const gekozenThema = localStorage.getItem("gekozenThema");
      if (gekozenThema) {
        const themaSpan = document.getElementById("gekozenThema");
        if (themaSpan) themaSpan.textContent = gekozenThema;
        laadVragen(gekozenThema);
      }
    }

    if (nr === 4) {
      toonEindScherm();
    }
  }

  document.addEventListener("DOMContentLoaded", () => {
    const opgeslagenNaam = localStorage.getItem("spelernaam");
    if (opgeslagenNaam) {
      const input = document.querySelector('.inputname');
      if (input) input.value = opgeslagenNaam;
      document.querySelectorAll('#spelernaam').forEach(span => span.textContent = opgeslagenNaam);
    }

    document.querySelectorAll(".thema").forEach(thema => {
      thema.addEventListener("click", () => {
        localStorage.setItem("gekozenThema", thema.textContent);
        nextScreen(3);
      });
    });

    const opnieuwBtn = document.querySelector(".quizopnieuw");
    if (opnieuwBtn) {
      opnieuwBtn.addEventListener("click", () => {
        localStorage.removeItem("gekozenThema");
        localStorage.removeItem("score");
        localStorage.removeItem("maxScore");
        localStorage.removeItem("answers");
        nextScreen(1);
      });
    }
  });

  function shuffleArray(array) {
    const newArr = [...array];
    for (let i = newArr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [newArr[i], newArr[j]] = [newArr[j], newArr[i]];
    }
    return newArr;
  }

  function laadVragen(thema) {
    let index = 0;
    let score = 0;
    const answersData = [];

    fetch("vragen.json")
      .then(r => r.json())
      .then(data => {
        let vragenArray = [];
        if (thema === "Indonesisch eten") vragenArray = data.IndonesischEten;
        else if (thema === "GameCharacter") vragenArray = data.GameCharacter;
        else if (thema === "Gezondheid") vragenArray = data.Gezondheid;

        vragenArray = shuffleArray(vragenArray);

        if (!vragenArray.length) {
          alert("Geen vragen gevonden voor dit thema.");
          return;
        }

        function toonVraag(i) {
          const vraag = vragenArray[i];
          document.querySelector(".vraagtitel").textContent = vraag.vraag;
          document.querySelector(".vraagimage").src = "images/" + vraag.image;

          const knoppen = document.querySelectorAll(".antwoord");
          const antwoorden = vraag.antwoorden.map((tekst, idx) => ({
            tekst,
            correct: idx === 0
          }));

          const shuffled = shuffleArray(antwoorden);

          knoppen.forEach((knop, j) => {
            knop.textContent = shuffled[j].tekst;
            knop.onclick = () => {
              clearInterval(countdown);
              const juist = shuffled[j].correct;
              if (juist) score++;
              answersData.push({
                vraag: vraag.vraag,
                juist: juist,
                gekozen: shuffled[j].tekst,
                correctAntwoord: vraag.antwoorden[0]
              });
              i++;
              if (i < vragenArray.length) toonVraag(i);
              else {
                localStorage.setItem("score", score);
                localStorage.setItem("maxScore", vragenArray.length);
                localStorage.setItem("answers", JSON.stringify(answersData));
                updateScoreboard(localStorage.getItem("spelernaam"), score);
                nextScreen(4);
              }
            };
          });

          let timeLeft = 20;
          const timerDisplay = document.querySelector(".timer");
          if (timerDisplay) timerDisplay.textContent = timeLeft;

          const countdown = setInterval(() => {
            timeLeft--;
            if (timerDisplay) timerDisplay.textContent = timeLeft;
            if (timeLeft <= 0) {
              clearInterval(countdown);
              answersData.push({
                vraag: vraag.vraag,
                juist: false,
                gekozen: "Geen antwoord",
                correctAntwoord: vraag.antwoorden[0]
              });
              i++;
              if (i < vragenArray.length) toonVraag(i);
              else {
                localStorage.setItem("score", score);
                localStorage.setItem("maxScore", vragenArray.length);
                localStorage.setItem("answers", JSON.stringify(answersData));
                updateScoreboard(localStorage.getItem("spelernaam"), score);
                nextScreen(4);
              }
            }
          }, 1000);
        }

        toonVraag(index);
      });
  }

  function updateScoreboard(name, score) {
    let scoreboard = JSON.parse(localStorage.getItem("scoreboard")) || [];
    scoreboard.push({ name, score });
    scoreboard.sort((a, b) => b.score - a.score);
    scoreboard = scoreboard.slice(0, 3);
    localStorage.setItem("scoreboard", JSON.stringify(scoreboard));
  }

  function toonEindScherm() {
  const score = localStorage.getItem("score");
  const maxScore = localStorage.getItem("maxScore");
  const naam = localStorage.getItem("spelernaam");
  document.getElementById("score").textContent = score;
  document.getElementById("maxscore").textContent = maxScore;

  // Display the scoreboard
  const scoreboard = JSON.parse(localStorage.getItem("scoreboard")) || [];
  const ol = document.querySelector("#screen4 ol");
  if (ol) {
    ol.innerHTML = "";
    scoreboard.forEach(entry => {
      const li = document.createElement("li");
      li.textContent = `${entry.name} ${entry.score} punten`;
      ol.appendChild(li);
    });
  }

  // Display detailed question review
  const answersData = JSON.parse(localStorage.getItem("answers")) || [];
  const reviewContainer = document.createElement("div");
  reviewContainer.classList.add("review-container");

  answersData.forEach((item, idx) => {
    const questionBox = document.createElement("div");
    questionBox.classList.add("question-review");
    questionBox.innerHTML = `
      <strong>Vraag ${idx + 1}:</strong> ${item.vraag}<br>
      Deze vraag had je <span style="color:${item.juist ? "green" : "red"}">${item.juist ? "goed" : "fout"}</span><br>
      Jouw antwoord: ${item.gekozen}<br>
      Het juiste antwoord: ${item.correctAntwoord}
    `;
    reviewContainer.appendChild(questionBox);
  });

  document.getElementById("screen4").appendChild(reviewContainer);
}


