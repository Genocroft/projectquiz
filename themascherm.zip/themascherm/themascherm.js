document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".thema").forEach(thema => {
    thema.addEventListener("click", () => {
      window.location.href = "../vragenscherm/vragenscherm.html";
    });
  });
});
