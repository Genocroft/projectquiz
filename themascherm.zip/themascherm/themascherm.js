document.addEventListener("DOMContentLoaded", () => {
    const name = localStorage.getItem("spelernaam");
    if (name) {
        document.getElementById("spelernaam").textContent = name;
    }
});